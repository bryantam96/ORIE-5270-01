
CREATE TABLE taqtrade20141201 (

	A varchar,
	B varchar,
	C varchar,
	D varchar

);


CREATE TABLE taqtrade20141202 (

	A varchar,
	B varchar,
	C varchar,
	D varchar

);
