SELECT taqtrade20141201.c,taqtrade20141202.d FROM taqtrade20141201 INNER JOIN taqtrade20141202 ON taqtrade20141201.a = taqtrade20141202.a; 
