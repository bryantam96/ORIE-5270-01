\copy taqtrade20141201 FROM 'taqtrade20141201' DELIMITER ',' CSV;
\copy taqtrade20141202 FROM 'taqtrade20141202' DELIMITER ',' CSV;
